import {useState} from 'react'
import {CheckCircle2} from 'lucide-react'
import Field from '@/components/ui/Field'
import Button from '@/components/ui/Button'

// onSubmit(current, next) must return '' on success, or an error message.
export default function ChangePasswordForm({onSubmit,onDone}) {
  const [current,setCurrent]=useState('')
  const [next,setNext]=useState('')
  const [confirm,setConfirm]=useState('')
  const [error,setError]=useState('')
  const [busy,setBusy]=useState(false)
  const [done,setDone]=useState(false)

  const submit=async e=>{
    e.preventDefault()
    if(!current) return setError('Enter your current password.')
    if(next.length<6) return setError('New password must be at least 6 characters.')
    if(next===current) return setError('New password must be different from the current one.')
    if(next!==confirm) return setError('New password and confirm password do not match.')
    setBusy(true)
    const problem=await onSubmit(current,next)
    setBusy(false)
    if(problem) return setError(problem)
    setError('');setDone(true)
  }

  if(done) return (
    <div className="space-y-4 text-center">
      <CheckCircle2 className="mx-auto text-emerald-500" size={44}/>
      <div className="font-bold">Password changed</div>
      <p className="text-sm text-slate-500">Use the new password the next time you sign in.</p>
      <Button onClick={onDone} className="w-full">Done</Button>
    </div>
  )

  return (
    <form onSubmit={submit} className="space-y-4">
      <Field label="Current password" type="password" value={current} onChange={setCurrent} autoComplete="current-password" autoFocus/>
      <Field label="New password (min 6 characters)" type="password" value={next} onChange={setNext} autoComplete="new-password"/>
      <Field label="Confirm new password" type="password" value={confirm} onChange={setConfirm} autoComplete="new-password"/>
      {error&&<p className="form-error">{error}</p>}
      <div className="flex justify-end gap-2">
        <Button variant="secondary" onClick={onDone}>Cancel</Button>
        <Button type="submit" disabled={busy}>{busy?'Saving…':'Change password'}</Button>
      </div>
    </form>
  )
}